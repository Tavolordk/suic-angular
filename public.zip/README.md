# SuicAngular

This project was generated using [Angular CLI](https://github.com/angular/angular-cli) version 21.0.3.

## Development server

To start a local development server, run:

```bash
ng serve
```

Once the server is running, open your browser and navigate to `http://localhost:4200/`. The application will automatically reload whenever you modify any of the source files.

## Code scaffolding

Angular CLI includes powerful code scaffolding tools. To generate a new component, run:

```bash
ng generate component component-name
```

For a complete list of available schematics (such as `components`, `directives`, or `pipes`), run:

```bash
ng generate --help
```

## Building

To build the project run:

```bash
ng build
```

This will compile your project and store the build artifacts in the `dist/` directory. By default, the production build optimizes your application for performance and speed.

## Running unit tests

To execute unit tests with the [Vitest](https://vitest.dev/) test runner, use the following command:

```bash
ng test
```

## Running end-to-end tests

For end-to-end (e2e) testing, run:

```bash
ng e2e
```

Angular CLI does not come with an end-to-end testing framework by default. You can choose one that suits your needs.

## Additional Resources

For more information on using the Angular CLI, including detailed command references, visit the [Angular CLI Overview and Command Reference](https://angular.dev/tools/cli) page.

## Docker / servidor

El gateway ya no está fijo en el código. Para construir una imagen con gateway por defecto:

```powershell
.\build-docker.ps1 -Version "2.1.0" -GatewayUrl "http://10.237.3.42:8081"
```

El script genera `ssr-front_2.1.0.tar`. En el servidor usa `docker-compose.yml` y `.env`.
Si el gateway cambia después, basta actualizar `GATEWAY_URL` en `.env` y ejecutar:

```bash
docker compose up -d --force-recreate
```

No es necesario reconstruir Angular ni generar otro TAR para un cambio de IP/puerto.
