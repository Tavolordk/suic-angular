export interface Vehicle {
}
