import {
  require_react
} from "./chunk-I453PRMZ.js";
import "./chunk-H2SRQSE4.js";
export default require_react();
