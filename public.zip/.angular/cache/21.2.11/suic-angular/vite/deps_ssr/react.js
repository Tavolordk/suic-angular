import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_react
} from "./chunk-EN4A6SRN.js";
import "./chunk-6DU2HRTW.js";
export default require_react();
